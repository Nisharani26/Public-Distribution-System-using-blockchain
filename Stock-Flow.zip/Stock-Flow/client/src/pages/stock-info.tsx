import Layout from "@/components/layout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, XCircle, Check } from "lucide-react";
import { cn } from "@/lib/utils";

const stockItems = [
  { name: "Rice / चावल", qty: "450 kg", status: "Available", statusText: "Available / उपलब्ध" },
  { name: "Wheat / गेहूं", qty: "320 kg", status: "Available", statusText: "Available / उपलब्ध" },
  { name: "Sugar / चीनी", qty: "85 kg", status: "Low", statusText: "Low Stock / कम स्टॉक" },
  { name: "Kerosene / मिट्टी का तेल", qty: "0 L", status: "Out", statusText: "Out of Stock / स्टॉक खत्म" },
  { name: "Oil / तेल", qty: "120 L", status: "Available", statusText: "Available / उपलब्ध" },
];

export default function StockInfo() {
  return (
    <Layout 
      title="स्टॉक जानकारी" 
      subtitle="Stock Information"
      showBack
    >
      <div className="space-y-6">
        {/* Status Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 rounded-xl p-4 flex items-center gap-4 border border-green-100">
            <div className="bg-green-500 rounded-lg p-2 text-white">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-green-700 font-medium">Available</p>
              <p className="text-slate-600 text-sm">3 Items</p>
            </div>
          </div>
          <div className="bg-orange-50 rounded-xl p-4 flex items-center gap-4 border border-orange-100">
            <div className="bg-orange-500 rounded-lg p-2 text-white">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-orange-700 font-medium">Low Stock</p>
              <p className="text-slate-600 text-sm">2 Items</p>
            </div>
          </div>
          <div className="bg-red-50 rounded-xl p-4 flex items-center gap-4 border border-red-100">
            <div className="bg-red-500 rounded-lg p-2 text-white">
              <XCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-red-700 font-medium">Out of Stock</p>
              <p className="text-slate-600 text-sm">1 Item</p>
            </div>
          </div>
        </div>

        {/* Stock Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
            <div className="flex items-center gap-2 text-green-700 font-medium">
              <CheckCircle className="w-5 h-5" />
              <span>Current Stock / वर्तमान स्टॉक</span>
            </div>
            <Link href="/update-stock-mode">
              <Button className="bg-green-600 hover:bg-green-700">
                Update Stock / स्टॉक अपडेट करें
              </Button>
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="text-left py-4 px-6 font-bold text-slate-700">Item / सामान</th>
                  <th className="text-center py-4 px-6 font-bold text-slate-700">Quantity / मात्रा</th>
                  <th className="text-right py-4 px-6 font-bold text-slate-700">Status / स्थिति</th>
                </tr>
              </thead>
              <tbody>
                {stockItems.map((item, idx) => (
                  <tr key={idx} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50">
                    <td className="py-4 px-6 text-slate-700 font-medium">{item.name}</td>
                    <td className={cn(
                      "py-4 px-6 text-center font-bold",
                      item.status === "Available" && "text-blue-600",
                      item.status === "Low" && "text-orange-600",
                      item.status === "Out" && "text-red-600"
                    )}>{item.qty}</td>
                    <td className="py-4 px-6 flex justify-end">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 w-fit",
                        item.status === "Available" && "bg-green-100 text-green-700",
                        item.status === "Low" && "bg-orange-100 text-orange-700",
                        item.status === "Out" && "bg-red-100 text-red-700",
                      )}>
                        {item.status === "Available" && <Check className="w-3 h-3" />}
                        {item.status === "Low" && <AlertTriangle className="w-3 h-3" />}
                        {item.status === "Out" && <XCircle className="w-3 h-3" />}
                        {item.statusText}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}
