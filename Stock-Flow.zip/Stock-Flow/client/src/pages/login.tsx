import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Store, Lock, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

export default function Login() {
  const [_, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();

    if (isLocked) {
      toast.error("Account is locked. Please reset your PIN to unlock.", {
        action: {
          label: "Reset PIN",
          onClick: () => setLocation("/forgot-password")
        }
      });
      return;
    }

    if (!username || !pin) {
      toast.error("Please enter both username and PIN");
      return;
    }

    if (pin.length !== 4 || isNaN(Number(pin))) {
      toast.error("PIN must be exactly 4 digits");
      return;
    }

    // Simulate login logic
    const validUsers = [
      { user: "demo", pin: "1234" },
      { user: "shaktiration", pin: "1234" },
      { user: "suryaration", pin: "4321" },
      { user: "Banarasration", pin: "9765" }
    ];

    const isValidUser = validUsers.some(u => u.user === username && u.pin === pin);

    if (isValidUser) {
      toast.success("Login Successful! / लॉगिन सफल!");
      setTimeout(() => setLocation("/dashboard"), 500);
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      
      if (newAttempts >= 5) {
        setIsLocked(true);
        toast.error("Maximum attempts exceeded. Account Locked. Please reset PIN.");
      } else {
        toast.error(`Invalid Credentials. ${5 - newAttempts} attempts remaining.`);
      }
      setPin(""); // Clear PIN on error
    }
  };

  const handlePinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow numbers and max 4 digits
    if (/^\d*$/.test(value) && value.length <= 4) {
      setPin(value);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg border-0">
        <CardContent className="pt-10 pb-8 px-8">
          <div className="flex flex-col items-center mb-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Store className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-slate-800 text-center">दुकानदार लॉगिन</h1>
            <p className="text-green-700 font-medium">Shopkeeper Login</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label className="text-slate-600 text-base">Username / युजरनेम</Label>
              <div className="relative">
                <Store className="absolute left-3 top-3.5 h-5 w-5 text-slate-400" />
                <Input 
                  placeholder="Enter Username" 
                  className="pl-10 h-12 text-lg bg-white border-slate-200 focus-visible:ring-green-600"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isLocked}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-600 text-base">4-अंकीय पिन / 4-Digit PIN</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3.5 h-5 w-5 text-slate-400" />
                <Input 
                  type="password"
                  inputMode="numeric"
                  placeholder="Enter PIN" 
                  className="pl-10 h-12 text-lg bg-white border-slate-200 focus-visible:ring-green-600 font-mono tracking-widest"
                  value={pin}
                  onChange={handlePinChange}
                  maxLength={4}
                  disabled={isLocked}
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg bg-green-600 hover:bg-green-700 font-medium"
              disabled={isLocked}
            >
              {isLocked ? "Account Locked / खाता बंद है" : "लॉगिन करें / Login"}
            </Button>

            <div className="text-center">
              <a 
                href="#" 
                onClick={(e) => { e.preventDefault(); setLocation("/forgot-password"); }}
                className="text-green-700 hover:text-green-800 font-medium"
              >
                Forgot PIN? / पिन भूल गए?
              </a>
            </div>
          </form>

          {isLocked && (
            <div className="mt-6 bg-red-50 border border-red-200 rounded-lg p-4 text-center">
              <p className="text-red-700 font-medium">
                Too many incorrect attempts. Please use "Forgot PIN" to unlock your account.
              </p>
            </div>
          )}

          {!isLocked && (
            <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3">
              <div className="text-yellow-600 mt-1">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <p className="text-sm text-yellow-800">
                Allowed demo users: shaktiration (1234), suryaration (4321), Banarasration (9765)
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
