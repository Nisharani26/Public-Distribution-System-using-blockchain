import Layout from "@/components/layout";
import { Link } from "wouter";
import { 
  ClipboardList, 
  AlertTriangle, 
  Package, 
  Store, 
  FileText, 
  Box
} from "lucide-react";
import { Card } from "@/components/ui/card";

export default function Dashboard() {
  return (
    <Layout 
      title="दुकानदार पोर्टल" 
      subtitle="Shopkeeper Portal"
      showLogout
    >
      <div className="space-y-6">
        {/* Shop Info Card */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="bg-green-100 p-3 rounded-xl">
            <Store className="w-8 h-8 text-green-600" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Sarkari Ration Shop #45</h2>
            <p className="text-slate-500">Sector 12, District North</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-blue-500 text-white border-0 overflow-hidden relative h-32">
            <div className="p-6 relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <ClipboardList className="w-5 h-5" />
                <span className="font-medium">आज की रिक्वेस्ट</span>
              </div>
              <p className="text-xs opacity-90 mb-2">Today's Requests</p>
              <p className="text-3xl font-bold">12 <span className="text-lg font-normal opacity-90">Pending</span></p>
            </div>
          </Card>

          <Card className="bg-orange-500 text-white border-0 overflow-hidden relative h-32">
            <div className="p-6 relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5" />
                <span className="font-medium">कम स्टॉक</span>
              </div>
              <p className="text-xs opacity-90 mb-2">Low Stock</p>
              <p className="text-3xl font-bold">3 <span className="text-lg font-normal opacity-90">Items</span></p>
            </div>
          </Card>

          <Card className="bg-green-500 text-white border-0 overflow-hidden relative h-32">
            <div className="p-6 relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <Package className="w-5 h-5" />
                <span className="font-medium">आज वितरण</span>
              </div>
              <p className="text-xs opacity-90 mb-2">Today Delivered</p>
              <p className="text-3xl font-bold">28 <span className="text-lg font-normal opacity-90">Orders</span></p>
            </div>
          </Card>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link href="/requests">
            <div className="bg-blue-50 hover:bg-blue-100 transition-colors p-6 rounded-xl flex items-center gap-4 cursor-pointer">
              <div className="bg-blue-100 p-3 rounded-lg text-blue-600">
                <ClipboardList className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">रिक्वेस्ट देखें</h3>
                <p className="text-slate-500 text-sm">View Requests</p>
                <p className="text-red-500 text-xs mt-1 font-medium">12 New</p>
              </div>
            </div>
          </Link>

          <Link href="/stock">
            <div className="bg-green-50 hover:bg-green-100 transition-colors p-6 rounded-xl flex items-center gap-4 cursor-pointer">
              <div className="bg-green-100 p-3 rounded-lg text-green-600">
                <Box className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">स्टॉक देखें</h3>
                <p className="text-slate-500 text-sm">Stock Information</p>
              </div>
            </div>
          </Link>

          <Link href="/update-stock-mode">
            <div className="bg-blue-50 hover:bg-blue-100 transition-colors p-6 rounded-xl flex items-center gap-4 cursor-pointer">
              <div className="bg-blue-100 p-3 rounded-lg text-blue-600">
                <Package className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">स्टॉक अपडेट करें</h3>
                <p className="text-slate-500 text-sm">Update Stock</p>
              </div>
            </div>
          </Link>

          <Link href="/reports">
            <div className="bg-green-50 hover:bg-green-100 transition-colors p-6 rounded-xl flex items-center gap-4 cursor-pointer">
              <div className="bg-green-100 p-3 rounded-lg text-green-600">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">रिपोर्ट्स</h3>
                <p className="text-slate-500 text-sm">Download Reports</p>
              </div>
            </div>
          </Link>
        </div>

        {/* Low Stock Alert */}
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
          <div className="flex items-center gap-2 text-orange-800 font-bold mb-4">
            <AlertTriangle className="w-5 h-5" />
            <h3>Low Stock Alert / कम स्टॉक चेतावनी</h3>
          </div>
          <ul className="space-y-2 ml-7 text-orange-900 font-medium">
            <li>• Rice / चावल: 85 kg left</li>
            <li>• Sugar / चीनी: 45 kg left</li>
            <li>• Oil / तेल: 30 L left</li>
          </ul>
        </div>
      </div>
    </Layout>
  );
}
