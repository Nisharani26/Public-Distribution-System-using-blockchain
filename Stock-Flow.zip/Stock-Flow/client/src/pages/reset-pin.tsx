import { useState } from "react";
import { useLocation } from "wouter";
import { Store, Lock, Info, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ResetPin() {
  const [_, setLocation] = useLocation();
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);

  const isValid = newPin.length === 4 && confirmPin.length === 4 && newPin === confirmPin && /^\d+$/.test(newPin);

  const handlePinChange = (setter: (val: string) => void) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (/^\d*$/.test(val) && val.length <= 4) {
      setter(val);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      setShowSuccessDialog(true);
    }
  };

  const handleSuccessDismiss = () => {
    setShowSuccessDialog(false);
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg border-0">
        <CardContent className="pt-10 pb-8 px-8">
          <div className="flex flex-col items-center mb-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Store className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-slate-800 text-center">Reset PIN</h1>
            <p className="text-green-700 font-medium">Create New PIN</p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex gap-3">
             <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
             <p className="text-sm text-blue-800">
               Note: The PIN must be changed every 90 days from the date of signup for security purposes.
             </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label className="text-slate-600 text-base">New PIN / नया पिन</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3.5 h-5 w-5 text-slate-400" />
                <Input 
                  type="password"
                  inputMode="numeric"
                  placeholder="Enter 4-digit PIN" 
                  className="pl-10 h-12 text-lg bg-white border-slate-200 focus-visible:ring-green-600 font-mono tracking-widest"
                  value={newPin}
                  onChange={handlePinChange(setNewPin)}
                  maxLength={4}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-600 text-base">Confirm PIN / पिन की पुष्टि करें</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3.5 h-5 w-5 text-slate-400" />
                <Input 
                  type="password"
                  inputMode="numeric"
                  placeholder="Re-enter 4-digit PIN" 
                  className="pl-10 h-12 text-lg bg-white border-slate-200 focus-visible:ring-green-600 font-mono tracking-widest"
                  value={confirmPin}
                  onChange={handlePinChange(setConfirmPin)}
                  maxLength={4}
                />
              </div>
              {newPin && confirmPin && newPin !== confirmPin && (
                <p className="text-red-500 text-sm">PINs do not match</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg bg-green-600 hover:bg-green-700 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={!isValid}
            >
              Reset PIN / पिन रीसेट करें
            </Button>
          </form>
        </CardContent>
      </Card>

      <AlertDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader className="items-center text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <AlertDialogTitle className="text-xl">PIN Changed Successfully!</AlertDialogTitle>
            <AlertDialogDescription>
              Your PIN has been updated securely. A confirmation has been sent to your registered email/mobile.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center">
            <AlertDialogAction onClick={handleSuccessDismiss} className="bg-green-600 hover:bg-green-700 w-full sm:w-auto min-w-[120px]">
              Go to Login
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
