import { Link, useLocation } from "wouter";
import { ArrowLeft, LogOut, Store } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
  showBack?: boolean;
  showLogout?: boolean;
  backTo?: string;
  subtitle?: string;
}

export default function Layout({ 
  children, 
  title, 
  showBack = false, 
  showLogout = false,
  backTo = "/dashboard",
  subtitle 
}: LayoutProps) {
  const [_, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          {showBack && (
            <button 
              onClick={() => setLocation(backTo)}
              className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-600"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              {title || "Shopkeeper Portal"}
            </h1>
            {subtitle && <p className="text-sm text-green-600 font-medium">{subtitle}</p>}
          </div>
        </div>

        {showLogout && (
          <Link href="/">
            <button className="flex items-center gap-2 text-red-600 hover:bg-red-50 px-3 py-2 rounded-lg transition-colors font-medium">
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </Link>
        )}
      </header>

      <main className="max-w-5xl mx-auto p-4 md:p-6">
        {children}
      </main>
    </div>
  );
}
