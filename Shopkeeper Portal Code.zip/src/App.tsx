import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import RequestsList from './components/RequestsList';
import OTPVerification from './components/OTPVerification';
import VerificationSuccess from './components/VerificationSuccess';
import WeightEntry from './components/WeightEntry';
import ConfirmDelivery from './components/ConfirmDelivery';
import StockInformation from './components/StockInformation';
import DownloadReports from './components/DownloadReports';
import UpdateStock from './components/UpdateStock';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={
            isAuthenticated ? 
            <Navigate to="/dashboard" /> : 
            <Login onLogin={() => setIsAuthenticated(true)} />
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            isAuthenticated ? 
            <Dashboard onLogout={() => setIsAuthenticated(false)} /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/requests" 
          element={
            isAuthenticated ? 
            <RequestsList /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/otp-verification" 
          element={
            isAuthenticated ? 
            <OTPVerification /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/verification-success" 
          element={
            isAuthenticated ? 
            <VerificationSuccess /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/weight-entry" 
          element={
            isAuthenticated ? 
            <WeightEntry /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/confirm-delivery" 
          element={
            isAuthenticated ? 
            <ConfirmDelivery /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/stock" 
          element={
            isAuthenticated ? 
            <StockInformation /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/reports" 
          element={
            isAuthenticated ? 
            <DownloadReports /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/update-stock" 
          element={
            isAuthenticated ? 
            <UpdateStock /> : 
            <Navigate to="/" />
          } 
        />
      </Routes>
    </Router>
  );
}