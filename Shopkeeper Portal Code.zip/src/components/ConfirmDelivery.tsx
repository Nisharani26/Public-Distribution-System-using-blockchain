import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, CheckCircle, Shield, TriangleAlert } from 'lucide-react';
import { useState } from 'react';

export default function ConfirmDelivery() {
  const navigate = useNavigate();
  const location = useLocation();
  const { request, weights } = location.state || {};
  const [isConfirming, setIsConfirming] = useState(false);

  if (!request) {
    navigate('/requests');
    return null;
  }

  const deliveryItems = [
    { nameHi: 'चावल', nameEn: 'Rice', delivered: weights?.Rice || '15 kg' },
    { nameHi: 'गेहूं', nameEn: 'Wheat', delivered: weights?.Wheat || '5 kg' },
    { nameHi: 'चीनी', nameEn: 'Sugar', delivered: weights?.Sugar || '2 kg' }
  ];

  const handleConfirm = () => {
    setIsConfirming(true);
    // Simulate confirmation process
    setTimeout(() => {
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/weight-entry', { state: { request } })}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-teal-700">डिलीवरी पुष्टि</h1>
            <p className="text-sm text-gray-600">Confirm Delivery</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-6 py-8">
        {/* Citizen Details Card */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h3 className="text-gray-700 mb-4">Citizen Details / नागरिक का विवरण</h3>
          <div className="space-y-2">
            <p className="text-gray-800">
              <span className="text-gray-600">Name / नाम:</span> {request.name}
            </p>
            <p className="text-gray-800">
              <span className="text-gray-600">Ration ID:</span> {request.idNumber.replace('ID: ', '')}
            </p>
            <p className="text-gray-800">
              <span className="text-gray-600">Request ID:</span> REQ001
            </p>
          </div>
        </div>

        {/* Delivery Summary Card */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <h3 className="text-gray-700">Delivery Summary / डिलीवरी सारांश</h3>
          </div>
          
          <div className="space-y-4">
            {deliveryItems.map((item, index) => (
              <div key={index} className="flex justify-between items-center pb-3 border-b border-gray-100 last:border-0">
                <span className="text-gray-800">{item.nameEn} / {item.nameHi}</span>
                <div className="text-right">
                  <p className="text-blue-600">Delivered: {item.delivered}</p>
                  <p className="text-xs text-green-600 flex items-center justify-end gap-1 mt-1">
                    <CheckCircle className="w-3 h-3" />
                    Correct
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Blockchain Record Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6 mb-6">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-blue-900 mb-2">Blockchain Record / ब्लॉकचेन रिकॉर्ड</h4>
              <p className="text-sm text-blue-800 mb-1">
                यह लेनदेन ब्लॉकचेन पर दर्ज किया जाएगा और सत्यापित किया जाएगा।
              </p>
              <p className="text-sm text-blue-800">
                This transaction will be recorded and verified on blockchain.
              </p>
            </div>
          </div>
        </div>

        {/* Confirm Button */}
        <button
          onClick={handleConfirm}
          disabled={isConfirming}
          className="w-full bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white py-4 rounded-xl transition-colors mb-6 flex items-center justify-center gap-2"
        >
          {isConfirming ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Processing...</span>
            </>
          ) : (
            <>
              <CheckCircle className="w-5 h-5" />
              <span>✓ Confirm Delivery / डिलीवरी पुष्टि करें</span>
            </>
          )}
        </button>

        {/* Important Warning */}
        <div className="bg-orange-50 border border-orange-300 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <TriangleAlert className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-orange-900 mb-2">सावधान! / Important</h4>
              <p className="text-sm text-orange-800 mb-1">
                कृपया सुनिश्चित करें कि नागरिक को सही मात्रा में सामान मिला है।
              </p>
              <p className="text-sm text-orange-800">
                Please ensure citizen received correct quantity of items.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
