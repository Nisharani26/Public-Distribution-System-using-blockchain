import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Shield, TriangleAlert } from 'lucide-react';
import { useState } from 'react';

export default function OTPVerification() {
  const navigate = useNavigate();
  const location = useLocation();
  const { request } = location.state || {};
  const [pin, setPin] = useState('');

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length === 4) {
      navigate('/verification-success', { state: { request } });
    }
  };

  if (!request) {
    navigate('/requests');
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/requests')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-teal-700">OTP/PIN सत्यापन</h1>
            <p className="text-sm text-gray-600">OTP/PIN Verification</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-6 py-8">
        {/* Instructions Card */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-2xl p-6 mb-8">
          <div className="flex items-start gap-3 mb-4">
            <Shield className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-blue-900 mb-3">सत्यापन की प्रक्रिया / Verification Process</h3>
              <ul className="text-sm text-blue-800 space-y-2">
                <li>• नागरिक से पूछे व अपने फोन पे मांगे</li>
                <li>• Ask citizen for their 4-digit PIN</li>
                <li>• नीचे दिए गए कोटबॉक्स में 4-अंकीय पिन दर्ज करे</li>
                <li>• Enter the PIN in the box below</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Citizen Details Card */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-8">
          <h3 className="text-gray-700 mb-4">Citizen Details / नागरिक का विवरण</h3>
          <div className="space-y-2">
            <p className="text-gray-800">
              <span className="text-gray-600">Name / नाम:</span> {request.name}
            </p>
            <p className="text-gray-800">
              <span className="text-gray-600">Ration ID:</span> {request.idNumber.replace('ID: ', '')}
            </p>
            <p className="text-gray-800">
              <span className="text-gray-600">Request ID:</span> REQ001
            </p>
          </div>
        </div>

        {/* PIN Entry Card */}
        <div className="bg-white rounded-2xl shadow-sm p-8">
          <form onSubmit={handleVerify}>
            {/* PIN Display */}
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl text-green-600">0</span>
              </div>
              <p className="text-gray-700 mb-1">Enter Citizen OTP/PIN</p>
              <p className="text-sm text-teal-600">नागरिक की OTP/PIN दर्ज करे</p>
              <p className="text-sm text-gray-500 mt-2">4-अंकीय PIN / 4-Digit PIN</p>
            </div>

            {/* PIN Input */}
            <div className="mb-6">
              <input
                type="password"
                placeholder="Enter PIN"
                value={pin}
                onChange={(e) => setPin(e.target.value.slice(0, 4))}
                maxLength={4}
                className="w-full px-4 py-4 border border-gray-300 rounded-xl text-center text-xl tracking-widest focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Verify Button */}
            <button
              type="submit"
              disabled={pin.length !== 4}
              className="w-full bg-gray-300 hover:bg-gray-400 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 py-4 rounded-xl transition-colors"
            >
              Verify & Continue / सत्यापित करे और आगे बढे
            </button>
          </form>
        </div>

        {/* Warning Note */}
        <div className="bg-yellow-50 border border-yellow-300 rounded-xl p-4 mt-6">
          <div className="flex items-start gap-3">
            <TriangleAlert className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-yellow-900 mb-2">नोट / Note</h4>
              <p className="text-sm text-yellow-800">
                यदि नागरिक का PIN गलत है तो उन्हें दुबारा SMS देखने को कहें या सहायता केंद्र में संपर्क करे।
              </p>
              <p className="text-sm text-yellow-800 mt-1">
                If citizen's PIN is incorrect, ask them to check again or check their SMS.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
