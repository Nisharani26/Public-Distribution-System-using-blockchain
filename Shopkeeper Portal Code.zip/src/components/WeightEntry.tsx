import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Scale } from 'lucide-react';
import { useState } from 'react';

export default function WeightEntry() {
  const navigate = useNavigate();
  const location = useLocation();
  const { request } = location.state || {};

  const [weights, setWeights] = useState<{ [key: string]: string }>({});
  const [entryMode, setEntryMode] = useState<'manual' | 'auto'>('manual');

  if (!request) {
    navigate('/requests');
    return null;
  }

  const allocations = [
    { nameHi: 'चावल', nameEn: 'Rice', allocated: '15 kg' },
    { nameHi: 'गेहूं', nameEn: 'Wheat', allocated: '5 kg' },
    { nameHi: 'चीनी', nameEn: 'Sugar', allocated: '2 kg' }
  ];

  const handleWeightChange = (item: string, value: string) => {
    setWeights({ ...weights, [item]: value });
  };

  const handleDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to confirm delivery screen
    navigate('/confirm-delivery', { state: { request, weights } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/requests')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-teal-700">वजन दर्ज</h1>
            <p className="text-sm text-gray-600">Weight Entry</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-6 py-8">
        {/* Citizen Details Card */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h3 className="text-gray-700 mb-4">Citizen Details / नागरिक का विवरण</h3>
          <div className="space-y-2">
            <p className="text-gray-800">
              <span className="text-gray-600">Name / नाम:</span> {request.name}
            </p>
            <p className="text-gray-800">
              <span className="text-gray-600">Ration ID:</span> {request.idNumber.replace('ID: ', '')}
            </p>
            <p className="text-gray-800">
              <span className="text-gray-600">Request ID:</span> REQ001
            </p>
          </div>
        </div>

        {/* Weight Entry Mode */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h3 className="text-gray-700 mb-4">Weight Entry Mode / वजन दर्ज मोड</h3>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setEntryMode('manual')}
              className={`p-6 rounded-xl border-2 transition-all ${
                entryMode === 'manual'
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-white hover:bg-gray-50'
              }`}
            >
              <Scale className={`w-8 h-8 mx-auto mb-2 ${entryMode === 'manual' ? 'text-green-600' : 'text-gray-400'}`} />
              <p className={`${entryMode === 'manual' ? 'text-green-700' : 'text-gray-600'}`}>
                Manual Entry
              </p>
              <p className="text-sm text-gray-500">मैनुअल दर्ज</p>
            </button>
            <button
              onClick={() => setEntryMode('auto')}
              className={`p-6 rounded-xl border-2 transition-all ${
                entryMode === 'auto'
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-gray-100'
              }`}
              disabled
            >
              <Scale className="w-8 h-8 mx-auto mb-2 text-gray-300" />
              <p className="text-gray-400">Auto Weight</p>
              <p className="text-sm text-gray-400">ऑटो वजन (जल्द ही आएगा)</p>
            </button>
          </div>
        </div>

        {/* Weight Entry Form */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-2 mb-6">
            <Scale className="w-5 h-5 text-green-600" />
            <h3 className="text-gray-700">Enter Actual Weight / वास्तविक वजन दर्ज करे</h3>
          </div>

          <form onSubmit={handleDelivery}>
            <div className="space-y-4 mb-6">
              {allocations.map((item, index) => (
                <div key={index} className="border border-gray-200 rounded-xl p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div>
                      <p className="text-gray-800">{item.nameEn} / {item.nameHi}</p>
                    </div>
                    <span className="text-sm text-blue-600">Allocated: {item.allocated}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Enter weight"
                      value={weights[item.nameEn] || ''}
                      onChange={(e) => handleWeightChange(item.nameEn, e.target.value)}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                    <span className="text-gray-600">kg</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Delivery Button */}
            <button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-xl transition-colors"
            >
              Continue to Delivery / डिलीवरी पर आगे
            </button>
          </form>

          {/* Note Section */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex items-start gap-2 mb-3">
              <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs">i</span>
              </div>
              <h4 className="text-blue-800">नोट / Note</h4>
            </div>
            <ul className="text-sm text-blue-700 space-y-1 ml-7">
              <li>• सटीक वजन दर्ज करें</li>
              <li>• Enter accurate weight</li>
              <li>• नागरिक प्री के साथ दिकतियों के डिलीवरी करे</li>
              <li>• Confirm delivery after weight entry</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  );
}