import { useNavigate } from 'react-router-dom';
import { Store, LogOut, Clipboard, AlertTriangle, Package, FileText, RefreshCw, TriangleAlert } from 'lucide-react';

interface DashboardProps {
  onLogout: () => void;
}

export default function Dashboard({ onLogout }: DashboardProps) {
  const navigate = useNavigate();

  const stats = [
    {
      icon: Clipboard,
      titleHi: 'आज की रिक्वेस्ट',
      titleEn: "Today's Requests",
      count: '12',
      label: 'Pending',
      bgColor: 'bg-blue-500'
    },
    {
      icon: AlertTriangle,
      titleHi: 'कम स्टॉक',
      titleEn: 'Low Stock',
      count: '3',
      label: 'Items',
      bgColor: 'bg-orange-500'
    },
    {
      icon: Package,
      titleHi: 'आज वितरण',
      titleEn: 'Today Delivered',
      count: '28',
      label: 'Orders',
      bgColor: 'bg-green-500'
    }
  ];

  const actions = [
    {
      icon: Clipboard,
      titleHi: 'रिक्वेस्ट देखें',
      titleEn: 'View Requests',
      badge: '12 New',
      bgColor: 'bg-blue-50',
      iconBgColor: 'bg-blue-100',
      iconColor: 'text-blue-600',
      onClick: () => navigate('/requests')
    },
    {
      icon: Package,
      titleHi: 'स्टॉक देखें',
      titleEn: 'Stock Information',
      bgColor: 'bg-green-50',
      iconBgColor: 'bg-green-100',
      iconColor: 'text-green-600',
      onClick: () => navigate('/stock')
    },
    {
      icon: Package,
      titleHi: 'स्टॉक अपडेट करें',
      titleEn: 'Update Stock',
      bgColor: 'bg-blue-50',
      iconBgColor: 'bg-blue-100',
      iconColor: 'text-blue-600',
      onClick: () => navigate('/update-stock')
    },
    {
      icon: FileText,
      titleHi: 'रिपोर्ट्स',
      titleEn: 'Download Reports',
      bgColor: 'bg-green-50',
      iconBgColor: 'bg-green-100',
      iconColor: 'text-green-600',
      onClick: () => navigate('/reports')
    }
  ];

  const lowStockItems = [
    { nameHi: 'चावल', nameEn: 'Rice', quantity: '85 kg left' },
    { nameHi: 'चीनी', nameEn: 'Sugar', quantity: '45 kg left' },
    { nameHi: 'तेल', nameEn: 'Oil', quantity: '30 L left' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-gray-800">दुकानदार पोर्टल</h1>
            <p className="text-sm text-teal-600">Shopkeeper Portal</p>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 text-red-600 hover:text-red-700 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Shop Info Card */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center">
              <Store className="w-7 h-7 text-green-600" strokeWidth={2} />
            </div>
            <div>
              <h2 className="text-gray-800">Sarkari Ration Shop #45</h2>
              <p className="text-sm text-gray-600">Sector 12, District North</p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`${stat.bgColor} rounded-2xl p-6 text-white shadow-sm`}
            >
              <div className="flex items-center gap-3 mb-3">
                <stat.icon className="w-7 h-7" strokeWidth={2} />
                <div>
                  <div className="text-sm">{stat.titleHi}</div>
                  <div className="text-sm">{stat.titleEn}</div>
                </div>
              </div>
              <div className="mt-2">
                <div className="text-3xl">{stat.count} <span className="text-xl">{stat.label}</span></div>
              </div>
            </div>
          ))}
        </div>

        {/* Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {actions.map((action, index) => (
            <button
              key={index}
              onClick={action.onClick}
              className={`${action.bgColor} rounded-2xl p-6 text-left hover:shadow-md transition-shadow relative`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 ${action.iconBgColor} rounded-xl flex items-center justify-center`}>
                  <action.icon className={`w-6 h-6 ${action.iconColor}`} strokeWidth={2} />
                </div>
                <div>
                  <div className="text-gray-800">{action.titleHi}</div>
                  <div className="text-sm text-gray-600">{action.titleEn}</div>
                  {action.badge && (
                    <span className="text-sm text-red-500 mt-1 inline-block">
                      {action.badge}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Low Stock Alert */}
        <div className="bg-orange-50 border-2 border-orange-300 rounded-2xl p-6">
          <div className="flex items-start gap-3 mb-4">
            <TriangleAlert className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" strokeWidth={2} />
            <TriangleAlert className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" strokeWidth={2} />
            <div className="flex-1">
              <h3 className="text-orange-900 mb-3">
                Low Stock Alert / कम स्टॉक चेतावनी
              </h3>
              <ul className="space-y-2">
                {lowStockItems.map((item, index) => (
                  <li key={index} className="text-orange-900">
                    • {item.nameEn} / {item.nameHi}: {item.quantity}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}