import { useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import { useEffect } from 'react';

export default function VerificationSuccess() {
  const navigate = useNavigate();
  const location = useLocation();
  const { request } = location.state || {};

  useEffect(() => {
    if (!request) {
      navigate('/requests');
    }
  }, [request, navigate]);

  const handleContinue = () => {
    navigate('/weight-entry', { state: { request } });
  };

  if (!request) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-lg p-12 max-w-md w-full text-center">
        {/* Success Icon */}
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-12 h-12 text-green-600" strokeWidth={2.5} />
        </div>

        {/* Success Message */}
        <div className="mb-8">
          <h2 className="text-green-700 mb-2">✓ सत्यापित हो गया</h2>
          <p className="text-teal-600 mb-6">Verification Successful!</p>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-left">
            <p className="text-green-800 mb-2">
              नागरिक की पहचान सत्यापित हो गई है।
            </p>
            <p className="text-green-800">
              Citizen identity has been verified.
            </p>
            <p className="text-green-700 mt-3">
              अब वजन दर्ज करे।
            </p>
            <p className="text-green-700">
              Now proceed to weight entry.
            </p>
          </div>
        </div>

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-xl transition-colors"
        >
          Continue to Weight / वजन दर्ज करे
        </button>
      </div>
    </div>
  );
}
