import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, Download, Info } from 'lucide-react';

export default function DownloadReports() {
  const navigate = useNavigate();

  const reports = [
    {
      title: 'Daily Report',
      titleHi: 'दैनिक',
      period: 'Today',
      records: '28 records / रिकार्ड',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Weekly Report',
      titleHi: 'साप्ताहिक',
      period: 'This Week',
      records: '156 records / रिकार्ड',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Monthly Report',
      titleHi: 'मासिक',
      period: 'December 2024',
      records: '542 records / रिकार्ड',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ];

  const todaySummary = {
    deliveries: { label: 'Total Deliveries', labelHi: 'कुल डिलीवरी', value: '28 Orders' },
    quantity: { label: 'Total Quantity', labelHi: 'कुल मात्रा', value: '450 kg' },
    pending: { label: 'Pending Requests', labelHi: 'लंबित अनुरोध', value: '12 Orders' },
    lowStock: { label: 'Low Stock Items', labelHi: 'कम स्टॉक आइटम', value: '3 Items' }
  };

  const handleDownload = (reportType: string) => {
    // Demo: Simulate download
    alert(`Downloading ${reportType}...`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-gray-800">रिपोर्ट</h1>
            <p className="text-sm text-gray-600">Download Reports</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Download Reports Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-5 h-5 text-blue-600" />
            <h2 className="text-gray-800">रिपोर्ट डाउनलोड करे / Download Reports</h2>
          </div>
          <p className="text-sm text-gray-600 mb-6">
            दैनिक, साप्ताहिक या मासिक वितरण रिपोर्ट डाउनलोड करें
          </p>
          <p className="text-sm text-gray-600 mb-6">
            Download daily, weekly or monthly distribution reports
          </p>

          <div className="space-y-4">
            {reports.map((report, index) => (
              <div 
                key={index}
                className={`${report.bgColor} border border-gray-200 rounded-xl p-4 flex items-center justify-between`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                    <FileText className={`w-6 h-6 ${report.color}`} />
                  </div>
                  <div>
                    <h3 className="text-gray-800">{report.title}</h3>
                    <p className="text-sm text-gray-600">{report.period}</p>
                    <p className="text-sm text-gray-500">{report.records}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(report.title)}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg flex items-center gap-2 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>Download</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Today's Summary */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <h3 className="text-gray-800 mb-6">Today&apos;s Summary / आज का सारांश</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">{todaySummary.deliveries.label}</p>
              <p className="text-blue-700">{todaySummary.deliveries.value}</p>
            </div>
            <div className="bg-teal-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">{todaySummary.quantity.label}</p>
              <p className="text-teal-700">{todaySummary.quantity.value}</p>
            </div>
            <div className="bg-orange-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">{todaySummary.pending.label}</p>
              <p className="text-orange-700">{todaySummary.pending.value}</p>
            </div>
            <div className="bg-red-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">{todaySummary.lowStock.label}</p>
              <p className="text-red-700">{todaySummary.lowStock.value}</p>
            </div>
          </div>
        </div>

        {/* Note Section */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-blue-900 mb-2">नोट / Note</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• रिपोर्ट PDF फॉर्मेट में डाउनलोड होगी</li>
                <li>• Reports will be downloaded in PDF format</li>
                <li>• पूरी विवरणी के लिए मासिक रिपोर्ट डाउनलोड करें</li>
                <li>• Download monthly report for detailed information</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
