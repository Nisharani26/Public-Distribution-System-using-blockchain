import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, TriangleAlert, XCircle } from 'lucide-react';

interface StockItem {
  nameHi: string;
  nameEn: string;
  quantity: string;
  unit: string;
  status: 'available' | 'low' | 'out';
}

export default function StockInformation() {
  const navigate = useNavigate();

  const stockItems: StockItem[] = [
    { nameHi: 'चावल', nameEn: 'Rice', quantity: '450', unit: 'kg', status: 'available' },
    { nameHi: 'गेहूं', nameEn: 'Wheat', quantity: '320', unit: 'kg', status: 'available' },
    { nameHi: 'चीनी', nameEn: 'Sugar', quantity: '85', unit: 'kg', status: 'low' },
    { nameHi: 'मिट्टी का तेल', nameEn: 'Kerosene', quantity: '0', unit: 'L', status: 'out' },
    { nameHi: 'तेल', nameEn: 'Oil', quantity: '120', unit: 'L', status: 'available' },
    { nameHi: 'नमक', nameEn: 'Salt', quantity: '45', unit: 'kg', status: 'low' }
  ];

  const availableCount = stockItems.filter(item => item.status === 'available').length;
  const lowStockCount = stockItems.filter(item => item.status === 'low').length;
  const outOfStockCount = stockItems.filter(item => item.status === 'out').length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
            <CheckCircle className="w-4 h-4" />
            Available / उपलब्ध
          </span>
        );
      case 'low':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm">
            <TriangleAlert className="w-4 h-4" />
            Low Stock / कम स्टॉक
          </span>
        );
      case 'out':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm">
            <XCircle className="w-4 h-4" />
            Out of Stock / स्टॉक खत्म
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-gray-800">स्टॉक जानकारी</h1>
            <p className="text-sm text-gray-600">Stock Information</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        {/* Stock Status Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-green-50 border border-green-200 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-green-700">Available</p>
                <p className="text-green-900">{availableCount} Items</p>
              </div>
            </div>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                <TriangleAlert className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-orange-700">Low Stock</p>
                <p className="text-orange-900">{lowStockCount} Items</p>
              </div>
            </div>
          </div>

          <div className="bg-red-50 border border-red-200 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center">
                <XCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-red-700">Out of Stock</p>
                <p className="text-red-900">{outOfStockCount} Item</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stock Table */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <h2 className="text-gray-800">Current Stock / वर्तमान स्टॉक</h2>
            </div>
            <button 
              onClick={() => navigate('/update-stock')}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Update Stock / स्टॉक अपडेट करें
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-6 py-4 text-gray-700">Item / सामान</th>
                  <th className="text-center px-6 py-4 text-gray-700">Quantity / मात्रा</th>
                  <th className="text-center px-6 py-4 text-gray-700">Status / स्थिति</th>
                </tr>
              </thead>
              <tbody>
                {stockItems.map((item, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <span className="text-gray-800">{item.nameEn} / {item.nameHi}</span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`${
                        item.status === 'available' ? 'text-blue-600' :
                        item.status === 'low' ? 'text-orange-600' :
                        'text-red-600'
                      }`}>
                        {item.quantity} {item.unit}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      {getStatusBadge(item.status)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Low Stock Alert */}
        <div className="bg-orange-50 border border-orange-300 rounded-xl p-6 mt-6">
          <div className="flex items-start gap-3">
            <TriangleAlert className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-orange-900 mb-2">Low Stock Alert / कम स्टॉक चेतावनी</h3>
              <p className="text-sm text-orange-800 mb-1">
                कुछ आइटम कम या स्टॉक से बाहर हैं। कृपया जल्द ही स्टॉक अपडेट करें।
              </p>
              <p className="text-sm text-orange-800">
                Some items are running low or out of stock. Please update stock soon.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}