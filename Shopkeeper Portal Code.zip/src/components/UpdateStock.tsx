import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Info, FileText } from 'lucide-react';
import { useState } from 'react';

interface StockItem {
  nameHi: string;
  nameEn: string;
  current: string;
  unit: string;
}

export default function UpdateStock() {
  const navigate = useNavigate();
  
  const [stockUpdates, setStockUpdates] = useState<{ [key: string]: string }>({});

  const stockItems: StockItem[] = [
    { nameHi: 'चावल', nameEn: 'Rice', current: '450', unit: 'kg' },
    { nameHi: 'गेहूं', nameEn: 'Wheat', current: '320', unit: 'kg' },
    { nameHi: 'चीनी', nameEn: 'Sugar', current: '85', unit: 'kg' },
    { nameHi: 'मिट्टी का तेल', nameEn: 'Kerosene', current: '0', unit: 'L' },
    { nameHi: 'तेल', nameEn: 'Oil', current: '120', unit: 'L' },
    { nameHi: 'नमक', nameEn: 'Salt', current: '45', unit: 'kg' }
  ];

  const handleQuantityChange = (itemName: string, value: string) => {
    setStockUpdates({ ...stockUpdates, [itemName]: value });
  };

  const handleUpdateStock = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate stock update
    alert('Stock updated successfully!');
    navigate('/stock');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/stock')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-teal-700">स्टॉक अपडेट करे</h1>
            <p className="text-sm text-gray-600">Update Stock</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-6 py-8">
        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-blue-900 mb-2">निर्देश / Instructions</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• नया स्टॉक की मात्रा नीचे दर्ज करे (यह मात्रा स्टॉक में जोड़ा जाएगा)</li>
                <li>• Enter new stock quantity (this will be added to current stock)</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Add New Stock Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="flex items-center gap-2 mb-6">
            <Plus className="w-5 h-5 text-green-600" />
            <h2 className="text-gray-800">Add New Stock / नया स्टॉक जोड़े</h2>
          </div>

          <form onSubmit={handleUpdateStock}>
            <div className="space-y-4">
              {stockItems.map((item, index) => (
                <div key={index} className="border border-gray-200 rounded-xl p-4">
                  <div className="mb-3">
                    <h3 className="text-gray-800">{item.nameEn} / {item.nameHi}</h3>
                    <p className="text-sm text-gray-600">Current: {item.current} {item.unit}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Plus className="w-5 h-5 text-green-600" />
                    </div>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Enter quantity to add"
                      value={stockUpdates[item.nameEn] || ''}
                      onChange={(e) => handleQuantityChange(item.nameEn, e.target.value)}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <span className="text-gray-600 min-w-[30px]">{item.unit}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Update Button */}
            <button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-xl transition-colors mt-6"
            >
              Update Stock / स्टॉक अपडेट करें
            </button>
          </form>
        </div>

        {/* Note Section */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-blue-900 mb-2">नोट / Note</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• स्टॉक अपडेट करने के बाद ब्लॉकचेन पे रिकॉर्ड किया जाएगा</li>
                <li>• Stock update will be recorded on Blockchain</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
