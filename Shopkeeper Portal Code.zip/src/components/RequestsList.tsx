import { useNavigate } from 'react-router-dom';
import { ArrowLeft, User, CheckCircle, XCircle, Info } from 'lucide-react';
import { useState } from 'react';

interface Request {
  id: string;
  name: string;
  idNumber: string;
  timeAgo: string;
  items: Array<{
    nameHi: string;
    nameEn: string;
    quantity: string;
  }>;
}

export default function RequestsList() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState<Request[]>([
    {
      id: '1',
      name: 'Mohan Lal',
      idNumber: 'RAT345678',
      timeAgo: '1 hour ago',
      items: [
        { nameHi: 'गेहूं', nameEn: 'Wheat', quantity: '10 kg' },
        { nameHi: 'चीनी', nameEn: 'Sugar', quantity: '2 kg' }
      ]
    },
    {
      id: '2',
      name: 'Sita Devi',
      idNumber: 'RAT234567',
      timeAgo: '2 hours ago',
      items: [
        { nameHi: 'चावल', nameEn: 'Rice', quantity: '20 kg' },
        { nameHi: 'तेल', nameEn: 'Oil', quantity: '1 L' }
      ]
    }
  ]);

  const handleAccept = (requestId: string) => {
    const request = requests.find(r => r.id === requestId);
    if (request) {
      navigate('/otp-verification', { state: { request } });
    }
  };

  const handleReject = (requestId: string) => {
    setRequests(requests.filter(r => r.id !== requestId));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-gray-800">रिक्वेस्ट देखे</h1>
            <p className="text-sm text-gray-600">Pending Requests List</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-blue-800 mb-2">निर्देश / Instructions</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• रिक्वेस्ट स्वीकार करने से पहले OTP/PIN मांगे</li>
                <li>• After accepting, ask citizen for OTP/PIN verification</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Requests List */}
        <div className="space-y-4">
          {requests.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm p-12 text-center">
              <p className="text-gray-500">No pending requests</p>
            </div>
          ) : (
            requests.map((request) => (
              <div key={request.id} className="bg-white rounded-2xl shadow-sm p-6">
                {/* User Info */}
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-gray-800">{request.name}</h3>
                    <p className="text-sm text-gray-600">ID: {request.idNumber}</p>
                    <p className="text-sm text-orange-600">{request.timeAgo}</p>
                  </div>
                </div>

                {/* Requested Items */}
                <div className="mb-6">
                  <h4 className="text-gray-800 mb-4">Requested Items / मांगा गया सामान</h4>
                  <div className="space-y-3">
                    {request.items.map((item, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-700">
                          {item.nameEn} / {item.nameHi}
                        </span>
                        <span className="text-gray-800">{item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => handleAccept(request.id)}
                    className="bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span>Accept / स्वीकार करें</span>
                  </button>
                  <button
                    onClick={() => handleReject(request.id)}
                    className="bg-white border-2 border-red-500 text-red-600 hover:bg-red-50 py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    <XCircle className="w-5 h-5" />
                    <span>Reject / अस्वीकार करें</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}